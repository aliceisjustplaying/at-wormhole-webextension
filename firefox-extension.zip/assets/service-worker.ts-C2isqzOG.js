import { r as resolveDidToHandle, a as resolveHandleToDid, p as parseInput } from "./transform-C43ljfEO.js";
const DID_HANDLE_CACHE_KEY = "didHandleCache";
const MAX_CACHE_ENTRIES = 1e3;
const CLEANUP_THRESHOLD = 1.2 * MAX_CACHE_ENTRIES;
let didToHandle = /* @__PURE__ */ new Map();
const handleToDid = /* @__PURE__ */ new Map();
let isCacheDirty = false;
let cleanupScheduled = false;
async function loadCache() {
  try {
    const result = await chrome.storage.local.get(DID_HANDLE_CACHE_KEY);
    const stored = result[DID_HANDLE_CACHE_KEY];
    const rawEntries = typeof stored === "object" && stored != null ? Object.entries(stored) : [];
    const validEntries = [];
    for (const [key, val] of rawEntries) {
      if (typeof val === "object" && val != null) {
        const e = val;
        if (typeof e.handle === "string" && typeof e.lastAccessed === "number") {
          validEntries.push([key, { handle: e.handle, lastAccessed: e.lastAccessed }]);
        }
      }
    }
    didToHandle = new Map(validEntries);
    handleToDid.clear();
    for (const [did, entry] of didToHandle) {
      handleToDid.set(entry.handle, did);
    }
  } catch (error) {
    console.error("Failed to load cache:", error);
  }
}
let saveTimeout = null;
async function _doSave(resolve) {
  if (isCacheDirty) {
    try {
      await chrome.storage.local.set({
        [DID_HANDLE_CACHE_KEY]: Object.fromEntries(didToHandle)
      });
      isCacheDirty = false;
    } catch (error) {
      console.error("Failed to save cache:", error);
      if (error instanceof Error && error.message.includes("QUOTA_BYTES")) {
        await clearOldCacheEntries(0.5);
        void saveCache().then(resolve);
        return;
      }
    }
  }
  resolve();
}
async function saveCache() {
  isCacheDirty = true;
  if (saveTimeout) clearTimeout(saveTimeout);
  return new Promise((resolve) => {
    saveTimeout = setTimeout(() => {
      void _doSave(resolve);
    }, 1e3);
  });
}
async function updateCache(did, handle) {
  try {
    didToHandle.set(did, { handle, lastAccessed: Date.now() });
    handleToDid.set(handle, did);
    if (didToHandle.size > CLEANUP_THRESHOLD && !cleanupScheduled) {
      cleanupScheduled = true;
      setTimeout(() => {
        void cleanupCache().finally(() => {
          cleanupScheduled = false;
        });
      }, 0);
    }
    await saveCache();
  } catch (error) {
    console.error("Failed to update cache:", error);
  }
}
async function clearOldCacheEntries(ratio = 0.5) {
  if (didToHandle.size === 0) return;
  try {
    const entries = Array.from(didToHandle.entries());
    const sorted = entries.sort((a, b) => a[1].lastAccessed - b[1].lastAccessed);
    const toKeep = sorted.slice(-Math.floor(entries.length * (1 - ratio)));
    didToHandle = new Map(toKeep);
    handleToDid.clear();
    for (const [d, e] of didToHandle) {
      handleToDid.set(e.handle, d);
    }
    await saveCache();
  } catch (error) {
    console.error("Failed to clear old cache entries:", error);
  }
}
async function cleanupCache() {
  if (didToHandle.size <= MAX_CACHE_ENTRIES) return;
  try {
    const sorted = Array.from(didToHandle.entries()).sort((a, b) => a[1].lastAccessed - b[1].lastAccessed);
    const toKeep = sorted.slice(-MAX_CACHE_ENTRIES);
    didToHandle = new Map(toKeep);
    handleToDid.clear();
    for (const [d, e] of didToHandle) {
      handleToDid.set(e.handle, d);
    }
    await saveCache();
  } catch (error) {
    console.error("Failed to clean up cache:", error);
  }
}
const cacheLoaded = loadCache().catch(console.error);
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "UPDATE_CACHE" && typeof request.did === "string" && typeof request.handle === "string") {
    void updateCache(request.did, request.handle).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Failed to update cache via message:", error);
      sendResponse({ success: false, error: error instanceof Error ? error.message : String(error) });
    });
    return true;
  }
  if (request.type === "GET_HANDLE" && typeof request.did === "string") {
    void (async () => {
      await cacheLoaded;
      try {
        const entry = didToHandle.get(request.did);
        if (entry) {
          entry.lastAccessed = Date.now();
          void saveCache().catch(console.error);
          sendResponse({ handle: entry.handle });
          return;
        }
        const h = await resolveDidToHandle(request.did);
        if (h) await updateCache(request.did, h);
        sendResponse({ handle: h ?? null });
      } catch (e) {
        console.error("GET_HANDLE error", e);
        sendResponse({ handle: null });
      }
    })();
    return true;
  }
  if (request.type === "GET_DID" && typeof request.handle === "string") {
    void (async () => {
      await cacheLoaded;
      try {
        const d = handleToDid.get(request.handle);
        if (d) {
          const entry = didToHandle.get(d);
          if (entry) {
            entry.lastAccessed = Date.now();
            void saveCache().catch(console.error);
          }
          sendResponse({ did: d });
          return;
        }
        const dd = await resolveHandleToDid(request.handle);
        if (dd) await updateCache(dd, request.handle);
        sendResponse({ did: dd ?? null });
      } catch {
        sendResponse({ did: null });
      }
    })();
    return true;
  }
  if (request.type === "CLEAR_CACHE") {
    didToHandle.clear();
    handleToDid.clear();
    void chrome.storage.local.remove(DID_HANDLE_CACHE_KEY).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Failed to clear storage cache:", error);
      sendResponse({ success: false, error: error instanceof Error ? error.message : String(error) });
    });
    return true;
  }
  return false;
});
chrome.tabs.onUpdated.addListener((_tabId, info, tab) => {
  void (async () => {
    await cacheLoaded;
    try {
      if (info.status !== "complete" || !tab.url) return;
      const data = await parseInput(tab.url);
      if (!(data == null ? void 0 : data.did)) return;
      if (data.handle) {
        await updateCache(data.did, data.handle);
        return;
      }
      const cached = didToHandle.get(data.did);
      if (cached) {
        cached.lastAccessed = Date.now();
        void saveCache().catch(console.error);
        return;
      }
      const h = await resolveDidToHandle(data.did);
      if (h) await updateCache(data.did, h);
    } catch (error) {
      console.error("SW error", error);
    }
  })();
});
