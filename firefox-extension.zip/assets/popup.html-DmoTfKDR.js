import { p as parseInput, b as buildDestinations } from "./transform-C43ljfEO.js";
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
document.addEventListener("DOMContentLoaded", () => {
  void (async () => {
    var _a;
    const list = document.getElementById("dest");
    const emptyBtn = document.getElementById("emptyCacheBtn");
    list.addEventListener("click", (e) => {
      const anchor = e.target.closest("a");
      if (anchor == null ? void 0 : anchor.href) {
        e.preventDefault();
        e.stopPropagation();
        void chrome.tabs.create({ url: anchor.href });
        window.close();
      }
    });
    const showStatus = (msg) => {
      list.innerHTML = `<li>${msg}</li>`;
    };
    const createItem = ({ url, label }) => `
    <li>
      <a href="${url}" target="_blank" rel="noopener noreferrer"
         style="display:block;padding:6px 8px;border:1px solid #ccc;border-radius:6px;background:#fafafa;text-decoration:none;color:inherit;font-size:14px;">
        ${label}
      </a>
    </li>`;
    const render = (ds2) => {
      if (ds2.length) {
        list.innerHTML = ds2.map(createItem).join("");
      } else {
        showStatus("No actions available");
      }
    };
    const payload = new URLSearchParams(location.search).get("payload");
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeUrl = ((_a = tabs[0]) == null ? void 0 : _a.url) ?? "";
    const raw = payload ?? activeUrl;
    if (!raw) {
      showStatus("No URL or payload provided");
      return;
    }
    const info = await parseInput(raw);
    if (!(info == null ? void 0 : info.did) && !(info == null ? void 0 : info.atUri)) {
      showStatus("No DID or at:// found");
      return;
    }
    let ds = buildDestinations(info);
    render(ds);
    if (info.did && !info.handle) {
      let handleToUse = null;
      let errorStatusWasSet = false;
      showStatus("Resolving...");
      try {
        const response = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({ type: "GET_HANDLE", did: info.did }, (res) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(res);
            }
          });
        });
        handleToUse = response.handle;
      } catch (err) {
        console.error("GET_HANDLE error", err);
        showStatus("Error resolving");
        errorStatusWasSet = true;
      }
      if (handleToUse) {
        info.handle = handleToUse;
        ds = buildDestinations(info);
        render(ds);
      } else {
        if (!ds.length && !errorStatusWasSet) {
          showStatus("No actions available");
        }
      }
    }
    if (info.handle && !info.did) {
      let didToUse = null;
      let errorStatusWasSet = false;
      showStatus("Resolving...");
      try {
        const response = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({ type: "GET_DID", handle: info.handle }, (res) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(res);
            }
          });
        });
        didToUse = response.did;
      } catch (err) {
        console.error("GET_DID error", err);
        showStatus("Error resolving");
        errorStatusWasSet = true;
      }
      if (didToUse) {
        info.did = didToUse;
        ds = buildDestinations(info);
        render(ds);
      } else if (!ds.length && !errorStatusWasSet) {
        showStatus("No actions available");
      }
    }
    emptyBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const originalText = emptyBtn.textContent;
      emptyBtn.textContent = "Working...";
      emptyBtn.disabled = true;
      void (async () => {
        await chrome.storage.local.remove("didHandleCache");
        await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({ type: "CLEAR_CACHE" }, (rawRes) => {
            const res = rawRes;
            if (chrome.runtime.lastError) {
              console.error("Runtime error sending message:", chrome.runtime.lastError);
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            if (res.success) {
              resolve();
            } else {
              reject(new Error(res.error ?? "Unknown error from service worker"));
            }
          });
        });
        emptyBtn.textContent = "Cleared";
      })().catch((error) => {
        console.error("Failed to clear cache:", error);
        emptyBtn.textContent = "Error";
      }).finally(() => {
        setTimeout(() => {
          emptyBtn.textContent = originalText;
          emptyBtn.disabled = false;
        }, 1500);
      });
    });
  })();
});
console.log("popup.js script finished initial global execution.");
