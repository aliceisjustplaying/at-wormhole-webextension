const NSID_SHORTCUTS = {
  post: "app.bsky.feed.post",
  feed: "app.bsky.feed.generator",
  lists: "app.bsky.graph.list"
};
async function parseInput(raw) {
  var _a;
  if (!raw) return null;
  const str = decodeURIComponent(raw.trim());
  if (!str.startsWith("http")) {
    return await canonicalize(str);
  }
  const atMatch = /at:\/\/[\w:.\-/]+/.exec(str);
  if (atMatch) {
    return await canonicalize(atMatch[0]);
  }
  try {
    const url = new URL(str);
    if (url.hostname === "cred.blue" && url.pathname.length > 1) {
      const handle = url.pathname.slice(1);
      if (handle) {
        return await canonicalize(handle);
      }
    }
    if (url.hostname === "tangled.sh" && url.pathname.length > 1) {
      const handle = url.pathname.slice(1).replace(/^@/, "");
      if (handle) {
        return await canonicalize(handle);
      }
    }
    if (url.hostname === "blue.mackuba.eu" && url.pathname.startsWith("/skythread")) {
      const author = url.searchParams.get("author");
      const post = url.searchParams.get("post");
      if ((author == null ? void 0 : author.startsWith("did:")) && post) {
        return await canonicalize(`${author}/app.bsky.feed.post/${post}`);
      }
    }
    const qParam = url.searchParams.get("q");
    if (qParam == null ? void 0 : qParam.startsWith("did:")) {
      return await canonicalize(qParam);
    }
    const parts = str.split(/[/?#]/);
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      if (p.startsWith("did:") || p.includes(".") && ((_a = parts[i - 1]) == null ? void 0 : _a.toLowerCase()) === "profile") {
        const rest = parts.slice(i + 1).join("/");
        const fragment = rest ? `${p}/${rest}` : p;
        return await canonicalize(fragment);
      }
    }
  } catch (error) {
    console.error("Error parsing input:", error);
  }
  return null;
}
async function canonicalize(fragment) {
  let f = fragment.replace(/^at:\/\/([^/])/, "at://$1");
  if (!f.startsWith("at://")) f = "at://" + f;
  const [, idAndRest] = f.split("at://");
  const [idPart, ...restParts] = idAndRest.split("/");
  let did = idPart.startsWith("did:") ? idPart : null;
  const handle = did ? null : idPart;
  if (!did && handle) {
    did = await resolveHandleToDid(handle);
  }
  if (restParts.length) {
    const first = restParts[0];
    if (NSID_SHORTCUTS[first]) {
      restParts[0] = NSID_SHORTCUTS[first];
    }
  }
  const pathRest = restParts.join("/");
  const [nsid, rkey] = pathRest.split("/").filter(Boolean);
  let bskyAppPath = "";
  const acct = handle ?? did;
  if (acct) {
    bskyAppPath = `/profile/${acct}`;
    if (nsid && rkey) {
      const shortcutKey = Object.keys(NSID_SHORTCUTS).find((key) => NSID_SHORTCUTS[key] === nsid);
      if (shortcutKey) {
        bskyAppPath += `/${shortcutKey}/${rkey}`;
      }
    }
  }
  if (!did) return null;
  return {
    atUri: `at://${did}${pathRest ? `/${pathRest}` : ""}`,
    did,
    handle,
    rkey,
    nsid,
    bskyAppPath
  };
}
function isRecord(x) {
  return typeof x === "object" && x !== null;
}
async function safeJson(resp) {
  if (!resp.ok) return null;
  const raw = await resp.json();
  return isRecord(raw) ? raw : null;
}
async function resolveHandleToDid(handle) {
  if (handle.startsWith("did:web:")) {
    const parts = handle.split(":");
    if (parts.length === 3) {
      try {
        const resp = await fetch(`https://${parts[2]}/.well-known/did.json`);
        const data = await safeJson(resp);
        return (data == null ? void 0 : data.id) ?? handle;
      } catch {
      }
    }
    return handle;
  }
  try {
    const resp = await fetch(
      `https://public.api.bsky.app/xrpc/com.atproto.identity.resolveHandle?handle=${encodeURIComponent(handle)}`
    );
    const data = await safeJson(resp);
    return (data == null ? void 0 : data.did) ?? null;
  } catch {
  }
  return null;
}
async function resolveDidToHandle(did) {
  if (!did) return null;
  if (did.startsWith("did:plc:")) {
    try {
      const resp = await fetch(`https://plc.directory/${encodeURIComponent(did)}`);
      const data = await safeJson(resp);
      const h = data ? _extractHandleFromAlsoKnownAs(data.alsoKnownAs) : null;
      if (h) return h;
    } catch {
    }
  }
  if (did.startsWith("did:web:")) {
    const url = _getDidWebWellKnownUrl(did);
    try {
      const resp = await fetch(url);
      const data = await safeJson(resp);
      const h = data ? _extractHandleFromAlsoKnownAs(data.alsoKnownAs) : null;
      if (h) return h;
    } catch {
    }
    return decodeURIComponent(did.substring("did:web:".length).split("#")[0]);
  }
  return null;
}
function _extractHandleFromAlsoKnownAs(alsoKnownAs) {
  if (Array.isArray(alsoKnownAs)) {
    for (const aka of alsoKnownAs) {
      if (typeof aka === "string" && aka.startsWith("at://")) {
        const handle = aka.substring("at://".length);
        if (handle) {
          return handle;
        }
      }
    }
  }
  return null;
}
function _getDidWebWellKnownUrl(did) {
  const methodSpecificId = decodeURIComponent(did.substring("did:web:".length).split("#")[0]);
  const parts = methodSpecificId.split(":");
  const hostAndPort = parts[0];
  let path = "";
  if (parts.length > 1) {
    path = "/" + parts.slice(1).join("/");
  }
  if (path.endsWith("/")) {
    path = path.slice(0, -1);
  }
  return `https://${hostAndPort}${path}/.well-known/did.json`;
}
function buildDestinations(info) {
  const { atUri, did, handle, rkey, bskyAppPath } = info;
  const isDidWeb = did.startsWith("did:web:");
  return [
    { label: "🦌 deer.social", url: `https://deer.social${bskyAppPath}` },
    { label: "🦋 bsky.app", url: `https://bsky.app${bskyAppPath}` },
    {
      label: "⚙️ pdsls.dev",
      url: `https://pdsls.dev/${atUri}`
    },
    {
      label: "🛠️ atp.tools",
      url: `https://atp.tools/${atUri}`
    },
    {
      label: "☀️ clearsky",
      url: `https://clearsky.app/${did}/blocked-by`
    },
    ...rkey ? [
      {
        label: "☁️ skythread",
        url: `https://blue.mackuba.eu/skythread/?author=${did}&post=${rkey}`
      }
    ] : [],
    ...handle ? [
      {
        label: "🍥 cred.blue",
        url: `https://cred.blue/${handle}`
      },
      {
        label: "🪢 tangled.sh",
        url: `https://tangled.sh/@${handle}`
      },
      {
        label: "📰 frontpage.fyi",
        url: `https://frontpage.fyi/profile/${handle}`
      }
    ] : [],
    ...!isDidWeb ? [
      {
        label: "⛵ boat.kelinci",
        url: `https://boat.kelinci.net/plc-oplogs?q=${did}`
      },
      {
        label: "🪪 plc.directory",
        url: `https://plc.directory/${did}`
      }
    ] : []
  ].filter((d) => Boolean(d.url));
}
export {
  resolveHandleToDid as a,
  buildDestinations as b,
  parseInput as p,
  resolveDidToHandle as r
};
